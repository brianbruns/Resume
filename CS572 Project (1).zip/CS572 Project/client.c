#include <stdio.h>      /* for printf() and fprintf() */
#include <sys/socket.h> /* for socket(), connect(), sendto(), and recvfrom() */
#include <arpa/inet.h>  /* for sockaddr_in and inet_addr() */
#include <stdlib.h>     /* for atoi() and exit() */
#include <string.h>     /* for memset() */
#include <unistd.h>     /* for close() */

#include <openssl/conf.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include "packet_header.h"

#define ECHOMAX 255     /* Longest string to echo */
#define MAX_ID_STRING 40


void DieWithError(char *errorMessage)  /* External error handling function */
{
    printf("ABORT: ");
    perror(errorMessage);
    exit(1);
}

int main(int argc, char *argv[])
{
    int sock;                        /* Socket descriptor */
    struct sockaddr_in echoServAddr; /* Echo server address */
    struct sockaddr_in authServAddr; /* Auth server address */
    struct sockaddr_in fromAddr;     /* Source address of echo */
    unsigned short echoServPort;     /* Echo server port */
    unsigned short authServPort;     /* Auth server port */
    unsigned int fromSize;           /* In-out of address size for recvfrom() */
    char *servIP;                    /* IP address of server */
    char *authIP;                    /* IP address of authentication server */
    int respStringLen;               /* Length of received response */
    char *clientKey;                 /* Shared key between client and AS*/
    char *clientID;                  /* String identifying client to not exceed 40 chars */
    char *serverID;                  /* String identifying server to not exceed 40 chars */
    int clientIDLen;
    unsigned int authAddrLen;         /* Length of incoming message */
    unsigned int echoServAddrLen;
    int serverIDLen;
    char sharedSecret[32];//gen_random_key(sharedSecret, KEY_LENGTH);
    memcpy(sharedSecret, "01234567890123456789012345678901", 32);

    /* A 128 bit IV */
    unsigned char iv[16];
    memset(iv, 0, 16);

    authIP = argv[1];               /* 2nd arg: auth server IP */
    authServPort = atoi(argv[2]);   /* 3rd arg: auth port */
    clientKey = argv[3];            /* 4th arg: shared key b/t client and server */
    echoServPort = atoi(argv[4]);   /* 5th arg: local port */
    servIP = argv[5];               /* 6th arg: AP IP */
    clientID = argv[6];             /* 7th arg: client name */
    serverID = argv[7];             /* 8th arg: server name */
    

    //./client <authservername> <authserverport> <clientkey> <server name> <server port> <clientID> <serverID>
    if (argc != 8)         /* Test for correct number of parameters */
    {
        fprintf(stderr,"Usage: <authservername> <authserverport> <clientkey> <server name> <server port> <clientID> <serverID>, %s\n", argv[0]);
        exit(1);
    }
    
    if ((clientIDLen = strlen(clientID)) > MAX_ID_STRING)  /* Check input length */
        DieWithError("Client name too long");
    if ((serverIDLen = strlen(serverID)) > MAX_ID_STRING)  /* Check input length */
        DieWithError("Server name too long");

    /* Create a datagram/UDP socket */
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
        DieWithError("socket() failed");

    /* Construct the server address structure */
    memset(&echoServAddr, 0, sizeof(echoServAddr));    /* Zero out structure */
    echoServAddr.sin_family = AF_INET;                 /* Internet addr family */
    echoServAddr.sin_addr.s_addr = inet_addr(servIP);  /* Server IP address */
    echoServAddr.sin_port   = htons(echoServPort);     /* Server port */

    memset(&authServAddr, 0, sizeof(authServAddr));    /* Zero out structure */
    authServAddr.sin_family = AF_INET;                 /* Internet addr family */
    authServAddr.sin_addr.s_addr = inet_addr(authIP);  /* Server IP address */
    authServAddr.sin_port   = htons(authServPort);     /* Server port */

    struct as_req request;
    memset(&request, 0, sizeof(request));
    request.type = AS_REQ;
    memcpy(&request.client_id, clientID, strlen(clientID));
    memcpy(&request.server_id, serverID, strlen(serverID));
    request.ts1 = time(NULL);

    

    if (sendto(sock, &request, sizeof(request), 0, (struct sockaddr *)
               &authServAddr, sizeof(authServAddr)) != sizeof(request))
        DieWithError("sendto() sent a different number of bytes than expected");

    printf("First one ok\n");
  
    struct as_rep asrep;
    memset(&asrep, 0, sizeof(asrep));

    if ((respStringLen = recvfrom(sock, &asrep, sizeof(asrep), 0,
            (struct sockaddr *) &authServAddr, &clientIDLen)) < 0)
            DieWithError("recvfrom() failed");

    printf("We got the error packet back\n");
    if (asrep.type != AS_REP) {
        DieWithError("Incorrect Packet Type");
    }
    // printf("response length: %d\n", respStringLen);

    // printf("\nt2: %s\n", credAS.tkt_serv);
    // printf("cipher: %s\n ", t2_ciphertext);
    // printf("ciphertextlen: %d\n", t2_ciphertextlen);
    unsigned char key[32];
    memset(key, 0, 32);
    strcpy(key, clientKey);

  //printf("This is the encrypted credential\n");
    //BIO_dump_fp (stdout, (const char*)&ASrespo.cred, ASrespo.cred_length);
    //printf("/n");
    unsigned char area_decrypted[1024];
    struct credential v2;

    //decrypt(t1_cipher, ciphertext_len, key, iv, (unsigned char *) &t2);
    //printf("decrypting with: %s\n", clientKey);
    int decryptsize;
    //printf("This is the decrypted credential:\n");
    printf("\nthis one?\n");
    decryptsize = decrypt(asrep.cred, asrep.cred_length, key, iv, area_decrypted);

    memcpy(&v2, area_decrypted, decryptsize);
   // v2.tkt_length = STICKET;
    
    struct auth Authenticator;
    memcpy(&Authenticator.client_id, clientID, clientIDLen);
    Authenticator.ts3 = time(NULL);

   // printf("\n");

    struct ap_req APrequest;
    APrequest.type = AP_REQ;
    memcpy(APrequest.tkt_serv, v2.tkt_serv, v2.tkt_length);
    APrequest.tkt_length = v2.tkt_length;
    //((unsigned char *) &t1, sizeof(struct ticket), key, iv, t1_cipher);
    unsigned char AuthEncrypted[SAUTH];
    //   int ciphertext_cred_len = encrypt((unsigned char *)&credAuthServer, sizeof(struct credential),key, iv, credential_cipher);
    int AuthLength = encrypt((unsigned char*)&Authenticator, sizeof(struct auth), sharedSecret, iv, AuthEncrypted);
    memcpy(&APrequest.auth, AuthEncrypted, AuthLength);
    APrequest.auth_length = AuthLength;

    if (sendto(sock, (struct ap_req*)&APrequest, sizeof(APrequest), 0, (struct sockaddr *) 
            &echoServAddr, sizeof(echoServAddr)) != sizeof(APrequest))
            DieWithError("sendto() sent a different number of bytes than expected");
    
    //get AP rep
    struct ap_rep apResponse;  /* create to handle to reception */
    memset(&apResponse, 0, sizeof(apResponse));
    
    // echoServAddrLen = sizeof(echoServAddr);
    printf("Right before it comes back\n");
    if((respStringLen = recvfrom(sock, &apResponse, sizeof(struct as_rep), 0,
             (struct sockaddr *) &echoServAddr, &echoServAddrLen)) < 0)
        DieWithError("recvfrom() failed");
    printf("There was another and I didnt get it\n");

    /* create pdata packet */
    struct pdata clientPData;
    memset(&clientPData, 0, sizeof(clientPData));
    clientPData.type = APP_DATA_REQ;
    clientPData.packet_length = strlen("One Sentence");  //application payload length. Just consider the length of the 
                                                     //data stored in the pdata.data field. Discard the rest of the fields
    clientPData.pid = 1;	//packet id, is a sequential number. Starts with 1.
    memcpy(clientPData.data, "One Sentence", strlen("One Sentence"));

    /* encrypt pdata packter */
    unsigned char pdata_cipher[BLOCK_SIZE];
    memset(&pdata_cipher, 0, sizeof(pdata_cipher));
    int pdata_ciphertext_len = encrypt((unsigned char *) &clientPData, 
            sizeof(struct ticket), sharedSecret, iv, pdata_cipher);
    
    /* create krb_prv packet */
    struct krb_prv mail;
    memset(&mail, 0, sizeof(mail));
    mail.type = KRB_PRV;
    mail.prv_length = pdata_ciphertext_len;               //encrypted data length
    memcpy(mail.prv, pdata_cipher, pdata_ciphertext_len); //encrypted data from struct pdata 

    printf("I am hitting the pre send line\n");
    /* send krb_prv */
    if (sendto(sock, (struct krb_prv*)&mail, (sizeof(mail)), 0, 
            (struct sockaddr *) &echoServAddr, sizeof(echoServAddr)) != sizeof(mail))
        DieWithError("sendto() sent a different number of bytes than expected"); 
    printf("First33 one ok\n");
    /* get krb_prv->app_data from server */
    struct krb_prv mail2;
    memset(&mail2, 0, sizeof(mail2));
    echoServAddrLen = sizeof(echoServAddr);
    if((respStringLen = recvfrom(sock, &mail2, sizeof(struct krb_prv), 0, 
            (struct sockaddr *) &echoServAddr, &echoServAddrLen)) < 0)
        DieWithError("recvfrom() failed");
    BIO_dump_fp (stdout, (const char *) &mail2, sizeof(mail2)); printf("\n");

    struct pdata clientPData2;
    memset(&clientPData2, 0, sizeof(clientPData2));
    printf("\nor this one?\n");

    int dec_clientPData2_len = decrypt(mail2.prv, mail2.prv_length, 
            sharedSecret, iv, (unsigned char *) &clientPData2);
    
    BIO_dump_fp (stdout, (const char *) &clientPData2, sizeof(clientPData2));
    // printf("%s\n", mail2.prv);
    // printf("%s\n", (unsigned char*) clientPData2);
    printf("\nOk\n");
    exit(0);
}

