#include <stdio.h>      /* for printf() and fprintf() */
#include <sys/socket.h> /* for socket() and bind() */
#include <arpa/inet.h>  /* for sockaddr_in and inet_ntoa() */
#include <stdlib.h>     /* for atoi() and exit() */
#include <string.h>     /* for memset() */
#include <unistd.h>     /* for close() */
#include "packet_header.h"

#include <openssl/conf.h>
#include <openssl/evp.h>
#include <openssl/err.h>

#define ECHOMAX 255     /* Longest string to echo */
#define KEY_LENGTH 32

void DieWithError(char *errorMessage)  /* External error handling function */
{
    printf("ABORT: ");
    perror(errorMessage);
    exit(1);
}

int main(int argc, char *argv[])
{
    int sock;                        /* Socket */
    struct sockaddr_in echoServAddr; /* Local address */
    struct sockaddr_in authServAddr; /* Auth address */
    struct sockaddr_in echoClntAddr; /* Client address */
    unsigned int cliAddrLen;         /* Length of incoming message */
    char echoBuffer[ECHOMAX];        /* Buffer for echo string */
    unsigned short echoServPort;     /* Server port */
    unsigned short authServPort;     /* Auth Server port*/
    int recvMsgSize;                 /* Size of received message */
    char *clientID;                  /* name of client */
    char *clientKey;                 /* secret key between client and AS */
    char *serverID;                  /* name of server */
    char *serverKey;                 /* secret key between AS and AP */
    char sharedSecret[32];
    memcpy(sharedSecret, "01234567890123456789012345678901", KEY_LENGTH);
    // ./authserver <authserverport> <clientID> <clientkey> <serverID> <serverkey>

    if(argc!= 6) {
        fprintf(stderr, "Usage: ./authserver <authserverport> <clientID> <clientkey> <serverID> <serverkey>, %s\n", argv[0]);
        exit(1);
    }

    authServPort = atoi(argv[1]);
    clientID = argv[2];
    clientKey = argv[3];
    serverID = argv[4];
    serverKey = argv[5];

    if(strlen(clientID) > 40 || strlen(serverID) > 40) {
        fprintf(stderr, "Usage: clientID and serverID must be below 40 characters");
    }

    /* Create socket for sending/receiving datagrams */
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
        DieWithError("socket() failed");
    /* Construct local address structure */
    memset(&echoServAddr, 0, sizeof(echoServAddr));   /* Zero out structure */
    echoServAddr.sin_family = AF_INET;                /* Internet address family */
    echoServAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
    echoServAddr.sin_port = htons(echoServPort);      /* Local port */

    /* Construct local address structure */
    memset(&authServAddr, 0, sizeof(authServAddr));   /* Zero out structure */
    authServAddr.sin_family = AF_INET;                /* Internet address family */
    authServAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
    authServAddr.sin_port = htons(authServPort);      /* Local port */

    /* Bind to the local address */
    if (bind(sock, (struct sockaddr *) &authServAddr, sizeof(authServAddr)) < 0)
        DieWithError("bind() failed");
    
  
    cliAddrLen = sizeof(echoClntAddr);
    
    struct as_req asreq;

    if ((recvMsgSize = recvfrom(sock, &asreq, sizeof(asreq), 0,
            (struct sockaddr *) &echoClntAddr, &cliAddrLen)) < 0)
            DieWithError("recvfrom() failed");

    if(asreq.type != AS_REQ) {
        struct as_err fail;
        fail.type = AS_ERR;
        memset(&fail.client_id, 0, 40);
        memcpy(&fail.client_id, clientID, sizeof(clientID));
        if (sendto(sock, (struct as_rep*) &fail, sizeof(fail), 0, (struct sockaddr *)
               &echoClntAddr, sizeof(echoClntAddr)) != sizeof(fail)) 
            DieWithError("sendto() sent a different number of bytes than expected");
        DieWithError("Incorrect packet type.");
    }

    //make iv
    unsigned char iv[16];
    memset(iv, 0, 16);

    //make ticket t1
    struct ticket t1;
    memset(&t1, 0, sizeof(t1));
    int t1_len = sizeof(struct ticket);
    memcpy(&t1.AES_key, sharedSecret, strlen(sharedSecret+1));
    memcpy(&t1.client_id, asreq.client_id, strlen(asreq.client_id));
    memcpy(&t1.server_id, asreq.server_id, strlen(asreq.server_id));
    t1.ts2 = time(NULL);
    t1.lt = LIFETIME;

    //make key
    unsigned char key[KEY_LENGTH];
    memset(key, 0, KEY_LENGTH);

    //make ciphertext
    unsigned char t1_cipher[STICKET];
    int t1_cipher_len = encrypt((unsigned char *) &t1, 
            sizeof(struct ticket), serverKey, iv, t1_cipher);

    //defining credential
    struct credential credAS;
    memset(&credAS, 0, sizeof(credAS));
    memcpy(&credAS.AES_key, sharedSecret, strlen(credAS.AES_key+1));
    memcpy(&credAS.server_id, asreq.server_id, strlen(asreq.server_id));
    credAS.ts2 = time(NULL);
    credAS.lt2 = LIFETIME;
    credAS.tkt_length = t1_cipher_len;
    memcpy(&credAS.tkt_serv, t1_cipher, t1_cipher_len);

    //encrypt credAS
    unsigned char credAS_cipher[SCRED];
    int cred_cipher_len = encrypt((unsigned char *) &credAS, sizeof(struct credential), sharedSecret, iv, credAS_cipher);
    
    struct as_rep asreply;
    memset(&asreply, 0, sizeof(asreply));
    asreply.type = AS_REP;
    asreply.cred_length = cred_cipher_len;
    memcpy(asreply.cred, credAS_cipher, cred_cipher_len);

    if (sendto(sock, &asreply, (sizeof(asreply)), 0, (struct sockaddr *) &echoClntAddr, sizeof(echoClntAddr)) != sizeof(asreply))
        DieWithError("sendto() sent a different number of bytes than expected");
    // printf("sending as_rep to client\n");
        
    printf("OK\n");
}

