#include <stdio.h>      /* for printf() and fprintf() */
#include <sys/socket.h> /* for socket() and bind() */
#include <arpa/inet.h>  /* for sockaddr_in and inet_ntoa() */
#include <stdlib.h>     /* for atoi() and exit() */
#include <string.h>     /* for memset() */
#include <unistd.h>     /* for close() */
#include "packet_header.h"

#include <openssl/conf.h>
#include <openssl/evp.h>
#include <openssl/err.h>

#define MAX_STRING 255     /* Longest string to echo */

void DieWithError(char *errorMessage)  /* External error handling function */
{
    printf("ABORT: ");
    perror(errorMessage);
    exit(1);
}

int main(int argc, char *argv[])
{
    
    int sock;                        /* Socket */
    struct sockaddr_in echoServAddr; /* Local address */
    struct sockaddr_in echoClntAddr; /* Client address */
    unsigned int cliAddrLen;         /* Length of incoming message */
    unsigned short echoServPort;     /* Server port */
    int recvMsgSize;                 /* Size of received message */
    char *serverKey;                 /* secret key between AS and AP */
    memset(&serverKey, 0, 32);

    unsigned char iv[16];
    unsigned char key[32];
    memset(iv, 0, 16);
 //memcpy(key, serverKey, sizeof(key));

    unsigned char SecretSharedKey[32];
    memset(&SecretSharedKey, 0, 32);
    memcpy(&SecretSharedKey, "01234567890123456789012345678901", 32);

    if (argc != 3)         /* Test for correct number of parameters */
    {
        fprintf(stderr,"Usage:  %s <UDP SERVER PORT>\n", argv[0]);
        exit(1);
    }

    echoServPort = atoi(argv[1]);   /* First arg:  local port */
    serverKey = argv[2];            /* Second arg: server key b/t AS and AP */
    memset(key, 0, 32);
    strcpy(key, serverKey);
    /* Create socket for sending/receiving datagrams */
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
        DieWithError("socket() failed");

    /* Construct local address structure */
    memset(&echoServAddr, 0, sizeof(echoServAddr));   /* Zero out structure */
    echoServAddr.sin_family = AF_INET;                /* Internet address family */
    echoServAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
    echoServAddr.sin_port = htons(echoServPort);      /* Local port */

    /* Bind to the local address */
    if (bind(sock, (struct sockaddr *) &echoServAddr, sizeof(echoServAddr)) < 0)
        DieWithError("bind() failed");
  
    cliAddrLen = sizeof(echoClntAddr);
    //printf("cliAddrLength is being created:%i\n", cliAddrLen);
   
    struct ap_req apRequest;

    if ((recvMsgSize = recvfrom(sock, &apRequest, sizeof(apRequest), 0,
            (struct sockaddr *) &echoClntAddr, &cliAddrLen)) < 0)
            DieWithError("recvfrom() failed");
    
     printf("Handling client %s\n", inet_ntoa(echoClntAddr.sin_addr));
    // echoBuffer[recvMsgSize] = '\0';
    // printf("Received: %s\n", echoBuffer);

    unsigned char decrypted[STICKET];
    for(int i = 0; i < STICKET; i++) {
        decrypted[i] = apRequest.tkt_serv[i];
    }

    struct ticket dec_ticket;
    memset(&dec_ticket, 0, sizeof(dec_ticket));
    int decrypted_ticket_len = decrypt(decrypted, apRequest.tkt_length, 
            serverKey, iv, (unsigned char *) &dec_ticket);

    long int ts3 = (dec_ticket.ts2 + 1);
    // int t2_len;
    // t2_len = sizeof(struct ticket);

    printf("here");
    //make nonce cipher
    unsigned char nonce_cipher[MINENC];
    memset(&nonce_cipher, 0, sizeof(long int));

    int nonce_ciphertext_len = encrypt((unsigned char *) &ts3, sizeof(long int),
             dec_ticket.AES_key, iv, nonce_cipher);

    //make ap response
    struct ap_rep apResponse;
    memset(&apResponse, 0, sizeof(apResponse));
    apResponse.type = AP_REP;
    apResponse.nonce_length = sizeof(dec_ticket.ts2+1);
    memcpy(&apResponse.nonce, (unsigned char *) &nonce_cipher, 
            sizeof(nonce_cipher));

    if (sendto(sock, (struct ap_rep*)&apResponse, (sizeof(apResponse)), 0, 
            (struct sockaddr *) &echoClntAddr, cliAddrLen) != sizeof(apResponse))
        DieWithError("sendto() sent a different number of bytes than expected");

    //make inital kerberos data
    struct krb_prv kp1;
    memset(&kp1, 0, sizeof(kp1));
    if((recvMsgSize = recvfrom(sock, &kp1, sizeof(struct krb_prv), 0, 
            (struct sockaddr *) &echoClntAddr, &cliAddrLen)) < 0)
        DieWithError("recvfrom() failed");
    printf("This is working on this side");
    if(kp1.type != KRB_PRV) {
        DieWithError("Timestamp not Authenticated");
    }

    //make server pdata
    struct pdata servPData;
    memset(&servPData, 0, sizeof(servPData));
    int dec_servPData_len = decrypt(kp1.prv, kp1.prv_length, dec_ticket.AES_key,
             iv, (unsigned char *) &servPData);

    //making second pdata
    struct pdata servPData2;
    memset(&servPData2, 0, sizeof(servPData2));
    servPData2.type = APP_DATA;
    servPData2.packet_length = strlen("Finally I got to send the data to the client. Succeed!");                                                                              //data stored in the pdata.data field. Discard the rest of the fields
    servPData2.pid = servPData.pid + 1;	
    memcpy(servPData2.data, "Finally I got to send the data to the client. Succeed!", strlen("Finally I got to send the data to the client. Succeed!"));
    
    //encrypt pdata
    unsigned char servPData2_cipher[BLOCK_SIZE];
    memset(&servPData2_cipher, 0, sizeof(servPData2_cipher));
    int servPData2_cipher_len = encrypt((unsigned char *) &servPData2, 
            sizeof(struct ticket), dec_ticket.AES_key, iv, servPData2_cipher);

    //create krb prv packet
    struct krb_prv returnMail;
    memset(&returnMail, 0, sizeof(returnMail));
    returnMail.type = KRB_PRV;
    returnMail.prv_length = servPData2_cipher_len;                   
    memcpy(returnMail.prv, servPData2_cipher, servPData2_cipher_len);  

    /* send app_data to client */
    if (sendto(sock, (struct ap_rep*)&returnMail, (sizeof(returnMail)), 0, 
            (struct sockaddr *) &echoClntAddr, cliAddrLen) != sizeof(returnMail))
        DieWithError("sendto() sent a different number of bytes than expected");

    printf("OK\n");
}

